package com.dd.main.service;

import com.dd.model.user.SysUser;

import java.util.List;

public interface IUserService {
    List<SysUser> getAllUser();
}

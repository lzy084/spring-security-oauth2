//package com.dd.cloud.gateway.config;
//
//import com.dd.cloud.gateway.handler.RedisLimiterLevelHandler;
//import com.dd.cloud.gateway.limiter.LimiterLevelResolver;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class RedisLimiterConfig {
//    @Bean
//    public LimiterLevelResolver limiterLevelResolver(){
//        return new RedisLimiterLevelHandler();
//    }
//}

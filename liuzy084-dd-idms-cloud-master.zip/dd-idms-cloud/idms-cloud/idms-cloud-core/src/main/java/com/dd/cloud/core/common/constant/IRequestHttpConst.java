package com.dd.cloud.core.common.constant;

public interface IRequestHttpConst {
    public static final String HTTP_RESPONSE_CONTENTTYPE = "application/json" + ";charset=utf-8";
    public static final String ROLE_PREFIX="ROLE_";
    public final static String SUPPER_ADMIN="ROLE_SUPPER_ADMIN";

}

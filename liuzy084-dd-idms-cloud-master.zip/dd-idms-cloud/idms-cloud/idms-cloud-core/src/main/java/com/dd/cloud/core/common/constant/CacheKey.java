package com.dd.cloud.core.common.constant;

public class CacheKey {
    public static final String USER_TOKEN="USER_TOKEN::";
    public static final String USER_INFO_PRI_KEY="USER_INFO::";
    public static final String USER_MENU_PRI_KEY="USER_MENU::";
}

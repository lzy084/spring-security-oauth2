package com.dd.cloud.core.base.user;

public class UserBase {
}

package com.dd.cloud.security.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface SecurityRoleMapper {
}

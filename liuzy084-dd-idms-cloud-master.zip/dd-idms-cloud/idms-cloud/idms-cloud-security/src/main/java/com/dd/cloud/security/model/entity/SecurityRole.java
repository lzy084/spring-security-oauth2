package com.dd.cloud.security.model.entity;

import com.dd.model.user.SysRole;
import lombok.Data;

@Data
public class SecurityRole extends SysRole {
}

package com.dd.cloud.security.model.entity;

import com.dd.model.user.SysMenu;

public class SecurityAuthority extends SysMenu {
}
